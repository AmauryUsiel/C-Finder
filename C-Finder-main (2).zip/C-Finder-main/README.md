# C-Finder
Implementación de proyecto para la materia de Análisis y Diseño orientado a objetos (ADOO), se usa Django y otras tecnologías.
